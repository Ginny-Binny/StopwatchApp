ifstream in("fileinputoutput.txt");
    // getline(in,st2);
    // cout<<st2;