#include<stdio.h>
int main(void)
{   
    printf(" Two roads diverged in a yellow wood \nAnd sorry I could not travel both \nAnd be one traveler, long I stood \nAnd looked down one as far as I could \nit bent in the undergrowth \n \n \nThen took the other, as just as fair \nAnd having perhaps the better claim \nBecause it was grassy and wanted wear \n Though as for that the passing there \nHad worn them really about the same \n \n \nAnd both that morning equally lay \nIn leaves no step had trodden black \n Oh, I kept the first for another day! \nYet knowing how way leads on to way\nI doubted if I should ever come back \n \n I shall be telling this with a sigh \nSomewhere ages and ages hence:\nTwo roads diverged in a wood, and I— \n I took the one less traveled by \nAnd that has made all the difference \n \n\n ");
    return 0;
} 