# MEI-v3
 The v3 of MEI Bot.
This is basically a lazy copy/paste of most of MEIv2's code but using Discord's slash command feature.

The quality of this code is, well, not beautiful but working. I have no interest about improving or making new features.
Thanks.
